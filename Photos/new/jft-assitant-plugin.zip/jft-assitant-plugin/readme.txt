=== JustFreeThemes Assistant ===
Contributors: themeisle,codeinwp,rozroz
Tags: themes, free, justfreethemes
Requires at least: 3.7
Tested up to: 4.9
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


JustFreeThemes Assistant is a small & lightweight plugin that connects and allows you to browse and install themes from JustFreeThemes.com.


== Description ==

JustFreeThemes Assistant is a small & lightweight plugin that connects and allows you to browse and install free wordpress themes from JustFreeThemes.com.


