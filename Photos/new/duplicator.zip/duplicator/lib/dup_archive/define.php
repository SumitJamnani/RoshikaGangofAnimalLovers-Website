<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
//Prevent directly browsing to the file
if(!defined('DUPARCHIVE_VERSION')) {
    // Should always match the version of Duplicator Pro that includes the library
    define('DUPARCHIVE_VERSION', '3.7.5.0');
}
